/*
 * Madhu Ratnakar
 * 12/01/2020
 * Video Game Design Final Project: Underwater Treasure Hunt
 * Instructions: Dive into the ocean to find all the tresure buried deep in the sea.
 *  Make sure to collect the floating oxygen bubbles, so you do not run out of 
 *  oxygen in your tank. Avoid bumping into the dangerous sea creatures who want to
 *  keep the treasure for themselves under the sea.
 *
 *  Data Structure/ Algorithms
 *    - Tilemap for game layout
 *    - FSM for shark moving
 *    - Bezier for stingray animation
 *    - game loop arcitecture
 *    - Particle systems for player bubble animation
 *
 * Starting Menu/Instruction Screen
 *    
 *   * Animations:
 *   - Ocean Waves
 *   - Fish swimming
 *   - Bubbles floating and popping
 *   - oxygen bubbles using particle systems for players swimming goggles
 *   - jellyfish moving and tenticles
 *   - treasure coin spin
 *   * Features:
 *   - Instructions and Start Game button on menu screen
 *   - return button on both screen
 *   - After levels are implemented, will connect that to the select level buttons
 *
 * Game Screen:
 *   * Features:
 *   - particle system bubbles from googles only appear when arrow keys are pressed
 *   - when keys are not pressed the player is sleeping and is sinking deeped slowly
 *   - when menu button is pressed, the game is reset when easy mode is selected again
 *   - the background color gets darker as the player goes down deeper
 *   - oxygen level keeps depleting constantly
 *   - when player touched NPCs the oxgen depletes faster
 *   - when player touches air bubble, oxygen increases
 *   - coin collection display at top left
 *   - fish moving in background
 *   - game tilemap filled with NPCs and air bubbles
 *   - game win and lose screen
 *   - oxygen level changes color based on how much oxygen is left
 *   - as player goes deeper, collecting coins gets harder and harder
 *   - player turns different color to indicate contact with enemy or bubble
 */

//GLOBAL VARIABLES
let OPTION = 0
let amp = 3;
let period = 20;
let waves = [];
let bird;
let bubblesStart = [];
let school = [];
let school2 = [];
let gameover = 0;
let airBubblesStart = [];
let bubbles1 = []; // for instruction screen
let theta;
let jellys = [];
let treasureWidth = 30;
let treasureDir = -1;

function preload() {
  //place any required pre loads here
}

/*
 *   setup function for game initialzing and starting screen, canvas size
 */
function setup() {
  createCanvas(640, 480);
  //frameRate(30); //TODO: watch this param for side effects
  angleMode(RADIANS);

  for (var i = 0; i < 20; i++) {
    waves.push(new Wave(25 + i * amp, 100 + i * period, color(155, 213, 242, 25 + i * 10)));
  }

  bird = new birdObj(random(20, 620), random(200, 400), 1);

  //prefill fish into the school array
  for (var i = 0; i < 25; i++) {
    school.push(new fishObj(random(40, width - 40), random(150, height)));
  }

  //prefill fish into the school array
  for (var i = 0; i < 500; i++) {
    school2.push(new fishObj(random(40, 600), random(150, 3600)));
  }

  theta = 0;
  for (var i = 0; i < 3; i++) {
    jellys[i] = new jellyFishStartObj(random(20, 620), random(200, 400), 20);
  }

  //below needed for easy level
  //game.initialize();
  numLayers = 100;
  layerHeight = 4000 / numLayers;
  startCol = color(17, 162, 240);
  endCol = color(26, 33, 68);
  colIncr = 1 / numLayers;

};

//***************************************************************************
//OBJECT DECLARATIONS BELOW//

var gameObj = function() {
  //16 each row
  this.tilemap = [
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBjaBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBjBBBBaB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBjB",
    "BBBjBBBaBBBBBBBB", //first coin
    "BBBBBBBBBBBBBBBB",
    "BBjBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBjBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBaBBBBBBB",
    "BBBBBBBBBBBBBBjB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBjBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBjBjBB", //second coin
    "BBBBBBBBBBBBjBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBaBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBaB",
    "BBBjBBBBBBBBBBBB",
    "BBBBBBBBBBBjBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBaBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBaBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBaBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BaBjBBBBBBBBBBBB",
    "BBBBjBBBBBBBBBBB",
    "BBBBBjBBBBBBBBBB",
    "BBBBBBjBjBjBjBjB", //third coin
    "BBBBBBBBBBBBBaBB",
    "BBBBjBBBBBBBBBBB",
    "BBBBajBBBBBBBBBB",
    "BBBBBBjBBBBBBBBB",
    "BBBBBBBBBBaBBBBj",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBjBBBBBBBBB",
    "BBBaBBBBBBBBBBBB",
    "BBBBBBBBBBBBjaBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBaBBBBBB",
    "BBBBjBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBaBBBBBBBBBBjBB",
    "BBjBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBjBBBBBBBBBB",
    "BBBBBBBBBBBBBBaB",
    "BBBBBBaBBBBBBBBB",
    "BBBBBBBBBBBBjBBB",
    "BBBBBBjBBBBBBBBB",
    "BBBjBjBjBBBBBBBB", //fourth coin
    "BBBBBBjBBBBjBBBB",
    "BBBBjjBBBBBBBBBB",
    "BBBBBBBBBBBBBjBB",
    "BBBBBBBBjBBBBBBB",
    "BBaBBBBBBBBBjBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBjBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBaBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "BBBBBjBBBBBBBBBB",
    "BBBBjBBBBBBBBBBB",
    "BBBBjBBjjjjjjjjj",
    "BBBBjBBBBBBBBBBB", //fifth
    "BaBBBjjjjjjjjjjj",
    "BBBBBBBBBBBBBBBB",
  ];
  this.gameOver = -1;
  this.score = 0;
  this.currFrame = 0;
  this.yCor = 0;
  this.xCor = 0;
  this.objects = [];
};

var coinObj = function(x, y) {
  this.position = new p5.Vector(x, y);
  this.width = 30;
  this.dir = -1;
  this.visible = 0;
};

/*
 *   coin object draw function
 */
coinObj.prototype.draw = function() {
  noStroke();
  if (this.visible == 0) {
    fill(245, 236, 159);
    ellipse(this.position.x, this.position.y, this.width, 30);
    fill(240, 221, 14);
    ellipse(this.position.x, this.position.y, this.width * 0.6, 16);
    this.width += this.dir;

    if ((this.width > 30) || (this.width < 0)) {
      this.dir = -this.dir;
    }
  }
};

var fishObj = function(x, y) {
  this.position = new p5.Vector(x, y);
  this.velocity = new p5.Vector(random(-0.75, 0), 0);
  this.acceleration = new p5.Vector(0.05, 0);
  this.c1 = random(255);
  this.c2 = random(255);
  this.c3 = random(255);
  this.dir = 1; //1 for left and -1 for right
};

var bubbleObj = function(x, y) {
  this.position = new p5.Vector(x, y);
  this.velocity = new p5.Vector(random(-5, -1), random(-0.5, 0.5));
  this.acceleration = new p5.Vector(0, -0.5);
  this.alpha = 255;
  this.size = 10;
};

var airBubbleStartObj = function(x, y, s) {
  this.position = new p5.Vector(x, y);
  this.velocity = new p5.Vector(0, -0.5);
  this.size = s;
};

var airBubbleObj = function(x, y, s) {
  this.position = new p5.Vector(x, y);
  this.velocity = new p5.Vector(0, -0.5);
  this.size = s;
};

var jellyFishStartObj = function(x, y) {
  this.position = new p5.Vector(x, y);
  this.velocity = new p5.Vector(0, -0.5);
};

var jellyFishObj = function(x, y) {
  this.position = new p5.Vector(x, y);
  this.width = 30;
  this.dir = 1;
  this.speed = 0.02;
};

var stingrayObj = function(x,y) {
    this.position = new p5.Vector(x, y);
    this.points = [];
    this.p2 = [];
    this.iterations = 0;
    this.init = 0;
    this.wanderDist = 0;
    this.step = new p5.Vector(0,0);
    this.i = 0;
    this.currFrame = 0;
};

var wanderState = function() {
    this.angle = 0;
    this.wanderDist = 0;
    this.step = new p5.Vector(0,0);
};

var chaseState = function() {
    this.step = new p5.Vector(0,0);
};

var sharkObj = function(x, y) {
    this.position = new p5.Vector(x, y);
    this.state = [new wanderState(), new chaseState()];
    this.currState = 0;
};

var objectObj = function(x, y, o) {
  this.x = x;
  this.y = y;
  this.obj = o;
};

var playerObj = function(x, y) {
  this.position = new p5.Vector(x, y);
  this.speed = 3;
  this.sinking = 0;
  this.life = true;
  this.win = false;
  this.color = 0;
};

var oxygenTankObj = function(x, y) {
  this.position = new p5.Vector(x, y);
  this.level = 90;
};

// *** END OF OBJECT DECLARATIONS ***

/*
 *   jellyfish object draw function
 */
jellyFishObj.prototype.draw = function(x, y) {
  this.position.x = x;
  this.position.y = y;
  noStroke();
  fill(237, 213, 232);
  arc(this.position.x, this.position.y, this.width, 50, PI, 0);
  strokeWeight(3);
  stroke(237, 213, 232);
  line(this.position.x, this.position.y, this.position.x, this.position.y + random(10, 20));
  line(this.position.x - 8, this.position.y, this.position.x - 8, this.position.y + random(10, 20));
  line(this.position.x + 8, this.position.y, this.position.x + 8, this.position.y + random(10, 20));

  if ((this.width > 40) || (this.width < 25)) {
    this.dir = -1 * this.dir;
  }
  if (this.dir === 1) {
    this.width += this.speed;
  } else if (this.dir === -1) {
    this.width -= this.speed;
  }
  noStroke();
};

//*************************************************************************

/*
 *   Below are all function for the stingray object and global vars
 */
let x1 = 0;
let y1 = 20;
let cx1 = 5;
let cy1 = 20;
let cx2 = -5;
let cy2 = 30;
let x2 = 0;
let y2 = 40;
let cx1Dir = 0.1;
let cx2Dir = -0.1;
let x2Dir = -0.1;

/*
 *   animating stingrays using switch case bezier shapes
 */
stingrayObj.prototype.wingsFlap = function() {
    switch(this.i) {
        case 0:
            this.points = [
                new p5.Vector(this.position.x, this.position.y-10),
                new p5.Vector(this.position.x+17, this.position.y-4),
                new p5.Vector(this.position.x+28, this.position.y+5),
                new p5.Vector(this.position.x+15, this.position.y+13),
                new p5.Vector(this.position.x+2, this.position.y+24),
                new p5.Vector(this.position.x, this.position.y+25),
                new p5.Vector(this.position.x-2, this.position.y+24),
                new p5.Vector(this.position.x-15, this.position.y+13),
                new p5.Vector(this.position.x-28, this.position.y+5),
                new p5.Vector(this.position.x-17, this.position.y-4),
                new p5.Vector(this.position.x, this.position.y-10)
            ];
            break;
        case 1:
            this.points = [
                new p5.Vector(this.position.x, this.position.y-10),
                new p5.Vector(this.position.x+14, this.position.y-4),
                new p5.Vector(this.position.x+22, this.position.y+5),
                new p5.Vector(this.position.x+11, this.position.y+13),
                new p5.Vector(this.position.x+1, this.position.y+24),
                new p5.Vector(this.position.x, this.position.y+25),
                new p5.Vector(this.position.x-1, this.position.y+24),
                new p5.Vector(this.position.x-11, this.position.y+13),
                new p5.Vector(this.position.x-22, this.position.y+5),
                new p5.Vector(this.position.x-14, this.position.y-4),
                new p5.Vector(this.position.x, this.position.y-10)
            ];
            break;
        case 2:
            this.points = [
                new p5.Vector(this.position.x, this.position.y-10),
                new p5.Vector(this.position.x+10, this.position.y-4),
                new p5.Vector(this.position.x+16, this.position.y+5),
                new p5.Vector(this.position.x+8, this.position.y+13),
                new p5.Vector(this.position.x+1, this.position.y+24),
                new p5.Vector(this.position.x, this.position.y+25),
                new p5.Vector(this.position.x-1, this.position.y+24),
                new p5.Vector(this.position.x-8, this.position.y+13),
                new p5.Vector(this.position.x-16, this.position.y+5),
                new p5.Vector(this.position.x-10, this.position.y-4),
                new p5.Vector(this.position.x, this.position.y-10)
            ];
            break;
        case 3:
            this.points = [
                new p5.Vector(this.position.x, this.position.y-10),
                new p5.Vector(this.position.x+14, this.position.y-4),
                new p5.Vector(this.position.x+22, this.position.y+5),
                new p5.Vector(this.position.x+11, this.position.y+13),
                new p5.Vector(this.position.x+1, this.position.y+24),
                new p5.Vector(this.position.x, this.position.y+25),
                new p5.Vector(this.position.x-1, this.position.y+24),
                new p5.Vector(this.position.x-11, this.position.y+13),
                new p5.Vector(this.position.x-22, this.position.y+5),
                new p5.Vector(this.position.x-14, this.position.y-4),
                new p5.Vector(this.position.x, this.position.y-10)
            ];
            break;
    }
};

/*
 *   stingray object splitpoints bezier function
 */
stingrayObj.prototype.splitPoints = function() {
    this.p2.splice(0, this.p2.length);
    for (var i = 0; i < this.points.length - 1; i++) {
        this.p2.push(new p5.Vector(this.points[i].x, this.points[i].y));
        this.p2.push(new p5.Vector((this.points[i].x + this.points[i+1].x)/2, (this.points[i].y +
this.points[i+1].y)/2));
    }
    this.p2.push(new p5.Vector(this.points[i].x, this.points[i].y));
    this.p2.push(new p5.Vector((this.points[0].x + this.points[i].x)/2, (this.points[0].y +
this.points[i].y)/2));
};

/*
 *   stingray object average bezier function
 */
stingrayObj.prototype.average = function() {
    for (var i = 0; i < this.p2.length - 1; i++) {
        var x = (this.p2[i].x + this.p2[i+1].x)/2;
        var y = (this.p2[i].y + this.p2[i+1].y)/2;
        this.p2[i].set(x, y);
    }
    var x = (this.p2[i].x + this.points[0].x)/2;
    var y = (this.p2[i].y + this.points[0].y)/2;
    this.points.splice(0, this.points.length);
    for (i = 0; i < this.p2.length; i++) {
        this.points.push(new p5.Vector(this.p2[i].x, this.p2[i].y));
    }
};

/*
 *   stingray object subdivision bezier function
 */
stingrayObj.prototype.subdivide = function() {
    this.splitPoints();
    this.average();
};

/*
 *   stingray object draw function
 */
stingrayObj.prototype.draw = function() {
    // if (this.init === 0) {
    //     this.butterflyShapeFull();
    //     this.init = 1;
    // }

    this.points.splice(0, this.points.length);
    this.wingsFlap();


    //if (this.iterations < 5) {
        this.subdivide();
        this.iterations++;
        this.init = 1; //initializaiton of the sub division is done
    //}

    translate(0,0);
    push();
    noStroke();
    beginShape();
    fill(94, 18, 201);

    for (var i = 0; i < this.points.length; i++) {
        vertex(this.points[i].x, this.points[i].y);
    }
    endShape();

    ellipse(this.position.x, this.position.y+24, 7, 7);

    //dots
    fill(201, 168, 250);
    ellipse(this.position.x-2, this.position.y, 3, 3);
    ellipse(this.position.x+3, this.position.y+2, 3, 3);
    ellipse(this.position.x-4, this.position.y+4, 3, 3);
    ellipse(this.position.x-1, this.position.y+8, 3, 3);
    ellipse(this.position.x-9, this.position.y+4, 3, 3);
    ellipse(this.position.x+9, this.position.y+5, 3, 3);
    ellipse(this.position.x+5, this.position.y+7, 3, 3);
    ellipse(this.position.x, this.position.y+13, 3, 3);

    push();
    translate(this.position.x,this.position.y);
    //beziers
    stroke(79, 20, 181);
    strokeWeight(3);
    noFill();

    bezier(x1, y1, cx1, cy1, cx2, cy2, x2, y2);
    cx1 += cx1Dir;
    if ((cx1 > x2) || (cx1 < x1)) {cx1Dir = -cx1Dir;}
    cx2 += cx2Dir;
    if ((cx2 < x1) || (cx2 > x2)) {cx2Dir = -cx2Dir;}
    x2 += x2Dir;
    if ((abs(x1 - x2) > 10) || (x2 < x1)) {x2Dir = -x2Dir;}

    noStroke();
    pop();

    pop();

    if (this.currFrame < (frameCount - 2)) {
        this.currFrame = frameCount;
        this.i++;
        if (this.i > 3) {
            this.i = 0;
        }
    }
};

/*
 *   stingray object move/roam function and checkcollision with player
 */
stingrayObj.prototype.roam = function() {
    if (this.wanderDist <= 0) {
        this.wanderDist = random(50, 80); //TODO
        this.angle = random(0, 2*PI);
        this.step.set(cos(this.angle), sin(this.angle));
    }
    this.wanderDist--;
    this.position.add(this.step);

    for (var i = 0; i < this.points.length; i++) {
        this.points[i].add(this.step);
    }

    if ((this.position.x > 620) || (this.position.x < 20) || (this.position.y > 3880) || (this.position.y < 20))
    {
        this.position.sub(this.step);
        for (var i = 0; i < this.points.length; i++) {
            this.points[i].sub(this.step);
        }
    }
  // check collision with player and stingray
  if (this.position.dist(player.position) <= 30) {
    oxygenTank.level -= 0.3;
    player.color = 1;
  }

};

// ****************************************************************************
// SHARK FUNCTIONS and for FSM

/*
 *   shark object changestate function
 */
sharkObj.prototype.changeState = function(x) {
    this.currState = x;
};

/*
 *   shark object wanderstate function
 */
wanderState.prototype.execute = function(me) {
    if (this.wanderDist <= 0) {
        this.wanderDist = random(50, 80);
        this.angle = random(0, 360);
        this.step.set(cos(this.angle), sin(this.angle));
    }
    this.wanderDist--;
    me.position.add(this.step);
    if (me.position.x > 620) {
        me.position.x = 619;
    }
    else if (me.position.x < 20) {
        me.position.x = 21;
    }
    if (me.position.y > 3880) {
        me.position.y = 3879;
    }
    else if (me.position.y < 20) {
        me.position.y = 21;
    }

    if (dist(me.position.x, me.position.y, player.position.x, player.position.y) < 150) {
        me.changeState(1);
    }
};

/*
 *   shark object chasestate function
 */
chaseState.prototype.execute = function(me) {
    if (dist(player.position.x, player.position.y, me.position.x, me.position.y) > 5) {
        this.step.set(player.position.x - me.position.x, player.position.y - me.position.y);
        this.step.normalize();
        this.step.mult(3);
        me.position.add(this.step);
    }

    if (dist(me.position.x, me.position.y, player.position.x, player.position.y) > 150) {
        me.changeState(0);
    }
};

/*
 *   shark object draw function
 */
sharkObj.prototype.draw = function() {
    noStroke();
    fill(123, 138, 143);
    triangle(this.position.x, this.position.y-30, this.position.x-9, this.position.y, this.position.x+9, this.position.y);
    triangle(this.position.x+7, this.position.y+4, this.position.x+12, this.position.y-4, this.position.x+30, this.position.y+15);
    triangle(this.position.x-7, this.position.y+4, this.position.x-12, this.position.y-4, this.position.x-30, this.position.y+15);
    fill(157, 168, 173);
    ellipse(this.position.x, this.position.y, 40, 32);
    fill(0, 0, 0);
    ellipse(this.position.x-10, this.position.y-3, 3, 3);
    ellipse(this.position.x+10, this.position.y-3, 3, 3);
    fill(173, 7, 7);
    ellipse(this.position.x, this.position.y+7, 20, 12);
    strokeWeight(3);
    stroke(255, 255, 255);
    line(this.position.x, this.position.y+3, this.position.x, this.position.y+3);
    line(this.position.x-5, this.position.y+3, this.position.x-5, this.position.y+3);
    line(this.position.x+5, this.position.y+3, this.position.x+5, this.position.y+3);
    line(this.position.x, this.position.y+10, this.position.x, this.position.y+10);
    line(this.position.x-5, this.position.y+10, this.position.x-5, this.position.y+10);
    line(this.position.x+5, this.position.y+10, this.position.x+5, this.position.y+10);
    noStroke();
};

/*
 *   // initialize game object based on tilemap initialization
 */
gameObj.prototype.initialize = function() {
  for (var i = 0; i < this.tilemap.length; i++) {
    for (var j = 0; j < this.tilemap[i].length; j++) {
      switch (this.tilemap[i][j]) {
        case 'a':
          this.objects.push(new objectObj(j * 40 + 20, i * 40 + 20, 1));
          airBubbles.push(new airBubbleObj(j * 40 + 20, i * 40 + 20));
          break;
        case 'j':
          this.objects.push(new objectObj(j * 40 + 20, i * 40 + 20, 2));
          jellyFishes.push(new jellyFishObj(j * 40 + 20, i * 40 + 20));
          break;
      }
    }
  }
};

/*
 *   // draw game background, call all draws of all game objects
 */
gameObj.prototype.draw = function() {
  print(game.length);
  for (var i = 0; i < this.tilemap.length; i++) {
    for (var j = 0; j < this.tilemap[i].length; j++) {
      switch (this.tilemap[i][j]) {
        case 'a':
          airBubble.draw(j * 40 + 20, i * 40 + 20);
          break;
        case 'j':
          jellyFish.draw(j * 40 + 20, i * 40 + 20);
          break;
      }
    }
  }
  for (var k = 0; k < coins.length; k++) {
    coins[k].draw();
  }
};

// *****************************************************************************

/*
 *   oxygentank object draw function
 */
oxygenTankObj.prototype.draw = function() {

  if (this.level >= 90) {
    this.level = 90;
  }

  fill(30, 30, 45); //background
  rect(this.position.x, this.position.y, 90, 25);

  if (this.level >= 60) {
    fill(22, 227, 22); //green
  } else if (this.level >= 30 && this.level < 60) {
    fill(227, 193, 22); //orange
  } else if (this.level < 30) {
    fill(227, 22, 97); //red
  } else if (this.level <= 0) {
    fill(30, 30, 45); //game over
    this.level = 0;
  }
  if (this.level >= 0) {
    rect(this.position.x, this.position.y, this.level, 25);
  }
  //this.width -= 0.01;
  this.level -= 0.01;
};

/*
 *   player object draw function
 */
playerObj.prototype.draw = function() {
  noStroke();
  fill(255, 255, 0);
  if(this.color === 1) {
    fill(255, 0, 0);
  }
  if(this.color === 2) {
    fill(0, 255, 0);
  }
  this.color = 0;

  ellipse(this.position.x, this.position.y, 24, 24);
  rect(this.position.x - 12, this.position.y, 24, 15);
  fill(162, 39, 207);
  rect(this.position.x - 12, this.position.y + 10, 24, 10);
  rect(this.position.x - 12, this.position.y + 18, 10, 5);
  rect(this.position.x + 2, this.position.y + 18, 10, 5);
  rect(this.position.x - 18, this.position.y + 10, 36, 5);
  fill(255, 0, 0);
  ellipse(this.position.x - 5, this.position.y - 1, 12, 12);
  ellipse(this.position.x + 5, this.position.y - 1, 12, 12);
  rect(this.position.x - 12, this.position.y - 10, 4, 12);
  fill(194, 252, 245);
  ellipse(this.position.x - 5, this.position.y - 1, 10, 10);
  ellipse(this.position.x + 5, this.position.y - 1, 10, 10);

  if (this.sinking === 1) {
    //add oxygen bubbles
    for (var i = 0; i < 1; i++) {
      bubbles.push(new bubbleObj(this.position.x - 10, this.position.y - 10));
    }
    //cleanup vanished bubbles
    for (var i = 0; i < bubbles.length; i++) {
      if (bubbles[i].alpha < 150) {
        bubbles.splice(i, 1);
      }
    }
    //draw the bubbles
    for (var i = 0; i < bubbles.length; i++) {
      bubbles[i].draw();
    }
  } else if (this.sinking === 0) {
    fill(0);
    textSize(9);
    //text("Zzz..", this.position.x-10, this.position.y-12);
  }
};

/*
 *   player object move function with keyboard logic
 */
playerObj.prototype.move = function() {
  // arrow key checks and move
  if (keyArray[LEFT_ARROW] === 1) {
    this.position.x -= this.speed;
    game.xCor += this.speed;

    if (game.xCor >= 100) {
      game.xCor = 100;
    }

  }
  if (keyArray[RIGHT_ARROW] === 1) {
    this.position.x += this.speed;
    game.xCor -= this.speed;

    if (game.xCor <= -100) {
      game.xCor = -100;
    }
  }
  if (keyArray[UP_ARROW] === 1) {
    this.position.y -= this.speed;
    game.yCor += this.speed;

    if (game.yCor >= 100) {
      game.yCor = 100;
    }
  }
  if (keyArray[DOWN_ARROW] === 1) {
    this.position.y += this.speed;
    game.yCor -= this.speed;

    if (game.yCor <= -3600) {
      game.yCor = -3600;
    }

  }
  this.position.y += 0.2;
  game.yCor -= 0.2;

  //border collision
  if (this.position.x <= 15) {
    this.position.x = 15;
    //game.Xcor = width;
  }
  if (this.position.x >= 625) {
    this.position.x = 625;
    //game.xCor = 0;
  }
  if (this.position.y <= 10) {
    this.position.y = 10;
    //game.xCor = 0;
  }
  if (this.position.y >= 3980) {
    this.position.y = 3980;
    //game.xCor = 0;
  }

};

/*
 *   airbubble object draw function for start screen
 */
airBubbleStartObj.prototype.draw = function() {
  stroke(209, 222, 240, 120);
  fill(255, 255, 255, 50);
  ellipse(this.position.x, this.position.y, this.size);
  fill(255, 255, 255, 180);
  ellipse(this.position.x + 0.2 * this.size, this.position.y - 0.2 * this.size, 0.2 * this.size);
};

airBubbleStartObj.prototype.draw = function() {
  stroke(209, 222, 240, 120);
  fill(255, 255, 255, 50);
  ellipse(this.position.x, this.position.y, this.size);
  fill(255, 255, 255, 180);
  ellipse(this.position.x + 0.2 * this.size, this.position.y - 0.2 * this.size, 0.2 * this.size);
};

/*
 *   air bubble object draw function
 */
airBubbleObj.prototype.draw = function(x, y) {
  this.position.x = x;
  this.position.y = y;
  strokeWeight(3);
  stroke(209, 222, 240, 120);
  fill(255, 255, 255, 50);
  ellipse(this.position.x, this.position.y, this.size);
  fill(255, 255, 255, 180);
  ellipse(this.position.x + 0.2 * this.size, this.position.y - 0.2 * this.size, 0.2 * this.size);

};

// **********************************************************************
// check collision functions with player below

airBubbleObj.prototype.checkCollision = function() {
  if (this.position.dist(player.position) <= 15) {
    //oxygenTank.width += 0.1;
    oxygenTank.level += 0.1;
    player.color = 2;
  }
};

coinObj.prototype.checkCollision = function() {
  if (this.position.dist(player.position) <= 15) {
    this.visible = 1;
  }
};

jellyFishObj.prototype.checkCollision = function() {
  if (this.position.dist(player.position) <= 30) {
    oxygenTank.level -= 0.3;
    player.color = 1;
  }
};

sharkObj.prototype.checkCollision = function() {
  if (this.position.dist(player.position) <= 25) {
    oxygenTank.level -= 0.3;
    player.color = 1;
  }
};

// ************************************************************************

var keyPressed = function() {
  keyArray[keyCode] = 1;
  player.sinking = 1;
};

var keyReleased = function() {
  keyArray[keyCode] = 0;
  player.sinking = 0;
};

airBubbleStartObj.prototype.float = function() {

  this.position.add(this.velocity);

};

let jellyWidth = 30;
let jellydir = 1;

jellyFishStartObj.prototype.draw = function() {
  noStroke();
  fill(237, 213, 232);
  arc(this.position.x, this.position.y, jellyWidth, 50, PI, 0);
  strokeWeight(3);
  stroke(237, 213, 232);
  line(this.position.x, this.position.y, this.position.x, this.position.y + random(10, 20));
  line(this.position.x - 8, this.position.y, this.position.x - 8, this.position.y + random(10, 20));
  line(this.position.x + 8, this.position.y, this.position.x + 8, this.position.y + random(10, 20));

  if ((jellyWidth > 40) || (jellyWidth < 25)) {
    jellydir = -1 * jellydir;
    //jellyWidth = jellyWidth + 2*jellydir;
  }
  if (jellydir === 1) {
    jellyWidth += 0.3;
  } else if (jellydir === -1) {
    jellyWidth -= 0.3;
  }
  noStroke();
};

jellyFishStartObj.prototype.float = function() {

  if ((this.position.y > height - 10) || (this.position.y < 200)) {
    this.velocity.y = this.velocity.y * -1;
  }

  this.position.add(this.velocity);

};

bubbleObj.prototype.draw = function() {
  //this.velocity.set(0,0);
  fill(random(255), this.alpha, random(255), 50);
  noStroke();
  ellipse(this.position.x, this.position.y, this.size, this.size);

  this.velocity.add(this.acceleration);
  this.position.add(this.velocity);
  this.alpha -= 5;
};

var Wave = function(amplitude, period, c) {
  this.startAngle = 0;
  this.amplitude = amplitude;
  this.period = period;
  this.color = c;
  this.angleVel = (TWO_PI / this.period) * 5;
};

Wave.prototype.update = function() {
  this.startAngle += TWO_PI / this.period;
};

Wave.prototype.draw = function() {
  var a = this.startAngle;
  noStroke();
  fill(this.color);
  for (var x = 0; x < width; x += 24) {
    var y = this.amplitude * sin(a);
    ellipse(x, y, 80, 60);
    a += this.angleVel;
  }
};

//starting screen player
var birdObj = function(x, y, d) {
  this.position = new p5.Vector(x, y);
  this.velocity = new p5.Vector(random(-0.2, 0.2), random(-0.5, 0.5));
  this.dir = d;

};

fishObj.prototype.draw = function() {
  fill(this.c1, this.c2, this.c3, 70);
  noStroke();
  triangle(this.position.x + 5 * this.dir, this.position.y, this.position.x + 15 * this.dir, this.position.y - 8, this.position.x + 15 * this.dir, this.position.y + 8);
  ellipse(this.position.x, this.position.y, 20, 15);
  stroke(28, 21, 27, 120);
  point(this.position.x - 6 * this.dir, this.position.y);

};

fishObj.prototype.roam = function() {

  this.position.add(this.velocity);

  if ((this.position.x > width - 40) || (this.position.x < 40)) {
    this.velocity.x = this.velocity.x * -1;
    this.dir = this.dir * -1;
  }

};

birdObj.prototype.draw = function() {

  fill(255, 255, 0);
  ellipse(this.position.x, this.position.y, 24, 24);
  rect(this.position.x - 12, this.position.y, 24, 15);
  fill(162, 39, 207);
  rect(this.position.x - 12, this.position.y + 10, 24, 10);
  rect(this.position.x - 12, this.position.y + 18, 10, 5);
  rect(this.position.x + 2, this.position.y + 18, 10, 5);
  rect(this.position.x - 18, this.position.y + 10, 36, 5);
  fill(255, 0, 0);
  ellipse(this.position.x - 5, this.position.y - 1, 12, 12);
  ellipse(this.position.x + 5, this.position.y - 1, 12, 12);
  rect(this.position.x - 12, this.position.y - 10, 4, 12);
  fill(194, 252, 245);
  ellipse(this.position.x - 5, this.position.y - 1, 10, 10);
  ellipse(this.position.x + 5, this.position.y - 1, 10, 10);

  //add bubbles Start
  for (var i = 0; i < 1; i++) {
    bubblesStart.push(new bubbleObj(this.position.x - 10, this.position.y - 10));
  }
  //cleanup vanished bubbles
  for (var i = 0; i < bubblesStart.length; i++) {
    if (bubblesStart[i].alpha < 150) {
      bubblesStart.splice(i, 1);
    }
  }
  //draw the bubbles
  for (var i = 0; i < bubblesStart.length; i++) {
    bubblesStart[i].draw();
  }

};

birdObj.prototype.roam = function() {

  if ((this.position.x > width - 20) || (this.position.x < 20)) {
    this.velocity.x = this.velocity.x * -1;
    if (this.position.x > width - 20) {
      this.d = 1;
    } else if (this.position.x < 20) {
      this.dir = 0;
    }
  }

  if ((this.position.y > height - 10) || (this.position.y < 100)) {
    this.velocity.y = this.velocity.y * -1;
  }

  this.position.add(this.velocity);

};

// draw game background, call all draws of all game objects
gameObj.prototype.draw = function() {
  for (var i = 0; i < this.tilemap.length; i++) {
    for (var j = 0; j < this.tilemap[i].length; j++) {
      switch (this.tilemap[i][j]) {
        case 'a':
          airBubble.draw(j * 40 + 20, i * 40 + 20);
          break;
        case 'j':
          jellyFish.draw(j * 40 + 20, i * 40 + 20);
          break;
      }
    }
  }
  for (var k = 0; k < coins.length; k++) {
    coins[k].draw();
  }
};

let stingrayIns = new stingrayObj(470,310);
let sharkIns = new sharkObj(530,320);

function instructionsDraw() {
  // player
  fill(255, 255, 0);
  ellipse(80, 270, 24, 24);
  rect(80 - 12, 270, 24, 15);
  fill(162, 39, 207);
  rect(80 - 12, 270 + 10, 24, 10);
  rect(80 - 12, 270 + 18, 10, 5);
  rect(80 + 2, 270 + 18, 10, 5);
  rect(80 - 18, 270 + 10, 36, 5);
  fill(255, 0, 0);
  ellipse(80 - 5, 270 - 1, 12, 12);
  ellipse(80 + 5, 270 - 1, 12, 12);
  rect(80 - 12, 270 - 10, 4, 12);
  fill(194, 252, 245);
  ellipse(80 - 5, 270 - 1, 10, 10);
  ellipse(80 + 5, 270 - 1, 10, 10);
  //add bubbles
  for (var i = 0; i < 1; i++) {
    bubbles1.push(new bubbleObj(80 - 10, 270 - 10));
  }
  //cleanup vanished bubbles
  for (var i = 0; i < bubbles1.length; i++) {
    if (bubbles1[i].alpha < 150) {
      bubbles1.splice(i, 1);
    }
  }
  //draw the bubbles
  for (var i = 0; i < bubbles1.length; i++) {
    bubbles1[i].draw();
  }

  //treasure
  fill(245, 236, 159);
  ellipse(200, 270, treasureWidth, 30);
  fill(240, 221, 14);
  ellipse(200, 270, treasureWidth * 0.6, 16);
  treasureWidth += treasureDir;

  if ((treasureWidth > 30) || (treasureWidth < 0)) {
    treasureDir = -treasureDir;
  }

  //oxygen bubbles
  stroke(209, 222, 240, 220);
  fill(255, 255, 255, 100);
  ellipse(350, 270, 25);
  fill(255, 255, 255, 180);
  ellipse(350 + 0.2 * 25, 270 - 0.2 * 25, 0.2 * 25);
  noStroke();

  // jellyfish
  fill(237, 213, 232);
  arc(500, 270, jellyWidth, 50, PI, 0);
  strokeWeight(3);
  stroke(237, 213, 232);
  line(500, 270, 500, 270 + random(10, 20));
  line(500 - 8, 270, 500 - 8, 270 + random(10, 20));
  line(500 + 8, 270, 500 + 8, 270 + random(10, 20));
  noStroke();

  // stingray
  stingrayIns.draw();

  //shark
  sharkIns.draw();

  fill(231, 240, 245);
  rect(30, 400, 290, 50);
  rect(50, 76, 530, 100);
  fill(0, 0, 0);
  textSize(30)
  text('Instructions', 240, 50)
  text('__________', 235, 60)
  textSize(16);
  text('Dive into the ocean to find all the treasure buried deep in the sea.', 60, 100);
  text('Make sure to collect the floating oxygen bubbles, so you do not run', 60, 120);
  text('out of oygen in your tank. Avoid bumping into the dangerous sea', 60, 140);
  text('creatures who want to keep the treasure for themselves under the sea.', 60, 160);

  textSize(14);
  text('Player                   Treasure                      Air Bubble', 60, 320);
  text('Enemies', 480, 380);

  textSize(20);
  text('Click here to return to Menu', 45, 430);
};

function resetGameScreen() {
  //reset player position to top of the screen
  player.position.x = 320;
  player.position.y = 230;

  //reset player life and win
  player.life = true;
  player.win = false;

  //reset oxygen tank level
  oxygenTank.level = 90;

  //reset treasure counts
  coins[0].visible = 0;
  coins[1].visible = 0;
  coins[2].visible = 0;
  coins[3].visible = 0;
  coins[4].visible = 0;

  //reset game xCor and yCor
  game.xCor = 0;
  game.yCor = 0;

  //reset game OPTION
  OPTION = 0;
};

function startGameDraw() {
  background(17, 162, 240);

  for (var i = 0; i < waves.length; i++) {
    waves[i].update();
    waves[i].draw();
  }
  fill(231, 240, 245);
  rect(30, 400, 290, 50);
  fill(0, 0, 0);
  textSize(30)
  text('Select Level', 240, 50)
  text('___________', 235, 60)
  textSize(20);
  text('Click here to return to Menu', 45, 430);

  // rectangle boxes for easy, med, hard
  fill(106, 85, 112);
  rect(30, 150, 150, 90);
  fill(22, 227, 22);
  fill(106, 85, 112);
  rect(220, 150, 150, 90);
  fill(227, 193, 22);
  fill(106, 85, 112);
  rect(410, 150, 150, 90);
  fill(227, 193, 22);
  fill(231, 240, 245);
  textSize(30);
  text('Easy             Medium            Hard', 70, 205);

};

//needed for easy level
var keyArray = [];
let player = new playerObj(320, 230);
let playerEnd = new playerObj(150, 65);
let game = new gameObj();
let oxygenTank = new oxygenTankObj(520, 35);
let coins = [new coinObj(100, 500), new coinObj(500, 1000), new coinObj(200, 2000), new coinObj(200, 3000), new coinObj(500, 3900)];
let numLayers, layerHeight;
let startCol, endCol, colIncr;
let airBubble = new airBubbleObj(0, 0, 30);
let airBubbles = [];
let jellyFish = new jellyFishObj(0, 0);
let jellyFishEnd = new jellyFishObj(150, 65);
let jellyFishes = [];
let bubbles = [];

//needed for medium level
var stingray1 = new stingrayObj(200,200);
var stingray2 = new stingrayObj(500,500);
var stingray3 = new stingrayObj(200,800);
var stingray4 = new stingrayObj(300,1100);
var stingray5 = new stingrayObj(400,1400);
var stingray6 = new stingrayObj(200,1700);
var stingray7 = new stingrayObj(200,2000);
var stingray8 = new stingrayObj(200,2300);
var stingray9 = new stingrayObj(500,2600);
var stingray10 = new stingrayObj(200,2900);
var stingray11 = new stingrayObj(300,3200);
var stingray12 = new stingrayObj(400,3500);
var stingray13 = new stingrayObj(200,3800);

//needed for hard level
var shark1 = new sharkObj(200, 600);
var shark2 = new sharkObj(400, 1000);
var shark3 = new sharkObj(300, 2100);
var shark4 = new sharkObj(300, 3000);
var shark5 = new sharkObj(400, 3800);

function easyLevelDraw() {
  background(94, 126, 168);
  push();
  translate(game.xCor, game.yCor);
  noStroke();
  for (let i = 0; i < numLayers; i++) {
    let waterCol = lerpColor(startCol, endCol, colIncr * i);
    fill(waterCol);
    rect(0, layerHeight * i, width, layerHeight);
  }
  game.draw();
  for (var i = 0; i < airBubbles.length; i++) {
    airBubbles[i].checkCollision();
  }
  for (var i = 0; i < coins.length; i++) {
    coins[i].checkCollision();
  }
  for (var i = 0; i < jellyFishes.length; i++) {
    jellyFishes[i].checkCollision();
  }
  player.draw();
  player.move();

  for (var i = 0; i < school.length; i++) {
    school2[i].draw();
    school2[i].roam();
  }

  pop();


  textSize(14);

  fill(255, 255, 255);
  rect(20, 440, 60, 20);
  fill(0, 0, 0);
  text("< Menu ", 27, 455);

  fill(255, 255, 255);
  text("Oxygen Level", 520, 30);
  oxygenTank.draw();

  fill(130, 140, 173);
  rect(20, 20, 100, 20);
  fill(115, 118, 128);
  ellipse(30, 30, 15, 15);
  ellipse(50, 30, 15, 15);
  ellipse(70, 30, 15, 15);
  ellipse(90, 30, 15, 15);
  ellipse(110, 30, 15, 15);
  if (coins[0].visible === 1) {
    fill(245, 245, 46);
    ellipse(30, 30, 15, 15);
  }
  if (coins[1].visible === 1) {
    fill(245, 245, 46);
    ellipse(50, 30, 15, 15);
  }
  if (coins[2].visible === 1) {
    fill(245, 245, 46);
    ellipse(70, 30, 15, 15);
  }
  if (coins[3].visible === 1) {
    fill(245, 245, 46);
    ellipse(90, 30, 15, 15);
  }
  if (coins[4].visible === 1) {
    fill(245, 245, 46);
    ellipse(110, 30, 15, 15);
  }
}

function mediumLevelDraw() {
  background(94, 126, 168);
  push();
  translate(game.xCor, game.yCor);
  noStroke();
  for (let i = 0; i < numLayers; i++) {
    let waterCol = lerpColor(startCol, endCol, colIncr * i);
    fill(waterCol);
    rect(0, layerHeight * i, width, layerHeight);
  }
  game.draw();
  for (var i = 0; i < airBubbles.length; i++) {
    airBubbles[i].checkCollision();
  }
  for (var i = 0; i < coins.length; i++) {
    coins[i].checkCollision();
  }
  for (var i = 0; i < jellyFishes.length; i++) {
    jellyFishes[i].checkCollision();
  }
  player.draw();
  player.move();

  for (var i = 0; i < school.length; i++) {
    school2[i].draw();
    school2[i].roam();
  }

  stingray1.draw();
  stingray1.roam();
  stingray2.draw();
  stingray2.roam();
  stingray3.draw();
  stingray3.roam();
  stingray4.draw();
  stingray4.roam();
  stingray5.draw();
  stingray5.roam();
  stingray6.draw();
  stingray6.roam();
  stingray7.draw();
  stingray7.roam();
  stingray8.draw();
  stingray8.roam();
  stingray9.draw();
  stingray9.roam();
  stingray10.draw();
  stingray10.roam();
  stingray11.draw();
  stingray11.roam();
  stingray12.draw();
  stingray12.roam();
  stingray13.draw();
  stingray13.roam();

  pop();


  textSize(14);

  fill(255, 255, 255);
  rect(20, 440, 60, 20);
  fill(0, 0, 0);
  text("< Menu ", 27, 455);

  fill(255, 255, 255);
  text("Oxygen Level", 520, 30);
  oxygenTank.draw();

  fill(130, 140, 173);
  rect(20, 20, 100, 20);
  fill(115, 118, 128);
  ellipse(30, 30, 15, 15);
  ellipse(50, 30, 15, 15);
  ellipse(70, 30, 15, 15);
  ellipse(90, 30, 15, 15);
  ellipse(110, 30, 15, 15);
  if (coins[0].visible === 1) {
    fill(245, 245, 46);
    ellipse(30, 30, 15, 15);
  }
  if (coins[1].visible === 1) {
    fill(245, 245, 46);
    ellipse(50, 30, 15, 15);
  }
  if (coins[2].visible === 1) {
    fill(245, 245, 46);
    ellipse(70, 30, 15, 15);
  }
  if (coins[3].visible === 1) {
    fill(245, 245, 46);
    ellipse(90, 30, 15, 15);
  }
  if (coins[4].visible === 1) {
    fill(245, 245, 46);
    ellipse(110, 30, 15, 15);
  }
}

function hardLevelDraw() {
  background(94, 126, 168);
  push();
  translate(game.xCor, game.yCor);
  noStroke();
  for (let i = 0; i < numLayers; i++) {
    let waterCol = lerpColor(startCol, endCol, colIncr * i);
    fill(waterCol);
    rect(0, layerHeight * i, width, layerHeight);
  }
  game.draw();
  for (var i = 0; i < airBubbles.length; i++) {
    airBubbles[i].checkCollision();
  }
  for (var i = 0; i < coins.length; i++) {
    coins[i].checkCollision();
  }
  for (var i = 0; i < jellyFishes.length; i++) {
    jellyFishes[i].checkCollision();
  }
  player.draw();
  player.move();

  for (var i = 0; i < school.length; i++) {
    school2[i].draw();
    school2[i].roam();
  }

  stingray1.draw();
  stingray1.roam();
  stingray2.draw();
  stingray2.roam();
  stingray3.draw();
  stingray3.roam();
  stingray4.draw();
  stingray4.roam();
  stingray5.draw();
  stingray5.roam();
  stingray6.draw();
  stingray6.roam();
  stingray7.draw();
  stingray7.roam();
  stingray8.draw();
  stingray8.roam();
  stingray9.draw();
  stingray9.roam();
  stingray10.draw();
  stingray10.roam();
  stingray11.draw();
  stingray11.roam();
  stingray12.draw();
  stingray12.roam();
  stingray13.draw();
  stingray13.roam();

  shark1.draw();
  shark1.state[shark1.currState].execute(shark1);
  shark1.checkCollision();

  shark2.draw();
  shark2.state[shark2.currState].execute(shark2);
  shark2.checkCollision();

  shark3.draw();
  shark3.state[shark3.currState].execute(shark3);
  shark3.checkCollision();

  shark4.draw();
  shark4.state[shark4.currState].execute(shark4);
  shark4.checkCollision();

  shark5.draw();
  shark5.state[shark5.currState].execute(shark5);
  shark5.checkCollision();

  pop();

  textSize(14);

  fill(255, 255, 255);
  rect(20, 440, 60, 20);
  fill(0, 0, 0);
  text("< Menu ", 27, 455);

  fill(255, 255, 255);
  text("Oxygen Level", 520, 30);
  oxygenTank.draw();

  fill(130, 140, 173);
  rect(20, 20, 100, 20);
  fill(115, 118, 128);
  ellipse(30, 30, 15, 15);
  ellipse(50, 30, 15, 15);
  ellipse(70, 30, 15, 15);
  ellipse(90, 30, 15, 15);
  ellipse(110, 30, 15, 15);
  if (coins[0].visible === 1) {
    fill(245, 245, 46);
    ellipse(30, 30, 15, 15);
  }
  if (coins[1].visible === 1) {
    fill(245, 245, 46);
    ellipse(50, 30, 15, 15);
  }
  if (coins[2].visible === 1) {
    fill(245, 245, 46);
    ellipse(70, 30, 15, 15);
  }
  if (coins[3].visible === 1) {
    fill(245, 245, 46);
    ellipse(90, 30, 15, 15);
  }
  if (coins[4].visible === 1) {
    fill(245, 245, 46);
    ellipse(110, 30, 15, 15);
  }
}

//main draw
function draw() {

  background(17, 162, 240);

  for (var i = 0; i < waves.length; i++) {
    waves[i].update();
    waves[i].draw();
  }

  bird.draw();
  bird.roam();

  for (var i = 0; i < school.length; i++) {
    school[i].draw();
    school[i].roam();
  }

  //air bubbles
  if (airBubblesStart.length < 5) {
    for (var i = 0; i < 1; i++) {
      airBubblesStart.push(new airBubbleStartObj(random(0, width), random(height - 200, height), random(20, 30)));
    }
  }

  //cleanup vanished air bubbles
  for (var i = 0; i < airBubblesStart.length; i++) {
    if (airBubblesStart[i].position.y < 150) {
      airBubblesStart.splice(i, 1);
    }
  }
  for (var i = 0; i < airBubblesStart.length; i++) {
    airBubblesStart[i].draw();
    airBubblesStart[i].float();
  }
  for (var i = 0; i < jellys.length; i++) {
    jellys[i].draw();
    jellys[i].float();
  }

  //title
  fill(106, 85, 112);
  textSize(40);
  text('Underwater Treasure Hunt', 80, 60);

  //creator
  fill(0, 0, 0);
  textSize(12);
  text("Created by Madhu Ratnakar", 480, 470);

  //check for player oxygen level
  if (oxygenTank.level <= 0) {
    player.life = false;
  }

  //check for treasure count... if total of 5 then end the game
  if ((coins[0].visible === 1) &&
    (coins[1].visible === 1) &&
    (coins[2].visible === 1) &&
    (coins[3].visible === 1) &&
    (coins[4].visible === 1)) {

    //game over.. all the coins collected.. player wins
    player.life = false;
    player.win = true;

  }

  if (!player.life) {
    //player life is false
    //game over

    if (!player.win) {

      fill(227, 193, 22);
      textSize(30);
      text('You Lose..', 240, 220);
    } else if (player.win) {

      //draw playerEnd in scaled up
      push();
      scale(2);
      playerEnd.draw();
      pop();

      fill(22, 227, 22);
      textSize(30);
      text('You Win !!!', 240, 220);
    }

    fill(227, 193, 22);
    textSize(30);
    text('Game Over. Please try again.', 120, 260);

    //reset the option and player settings
    OPTION = 0;
    gameover = 1;
    player.win = false;
    player.life = true;
    //show play again button
   fill(255, 255, 255);
   rect(20, 440, 80, 20);
   fill(0, 0, 0);
   textSize(15);
   text("Play Again", 27, 455);


  } else {
    //player life is true

    //option1
    fill(106, 85, 112);
    rect(80, 400, 150, 40);
    fill(255);
    textSize(25);
    text("Instructions", 91, 428);

    //option2
    fill(220, 0, 0);
    rect(400, 400, 150, 40);
    fill(255);
    textSize(25);
    text("Start Game", 411, 428);

    if (OPTION == 0) {
      //reset game screen
      resetGameScreen();
    }

    if (OPTION == 1) {
      background(17, 162, 240);
      for (var i = 0; i < waves.length; i++) {
        waves[i].update();
        waves[i].draw();
      }
      instructionsDraw();
    }

    // SHOW OPTIONS
    if (OPTION == 2) {
      startGameDraw();
    }

    if (OPTION == 3) {
      //easy
      easyLevelDraw();
    }

    if (OPTION == 4) {
      //medium
      mediumLevelDraw();
    }

    if (OPTION == 5) {
      //hard
      hardLevelDraw();
    }
  }
};

function mouseClicked() {

  if (OPTION === 0) {
   if (gameover === 1){
     if (mouseY < 460 && mouseY > 440) {
      if (mouseX < 100 && mouseX > 20) {
        gameover = 0; //reset this value for the next game
        resetGameScreen();
      }
     }
   }
    if (mouseY < 440 && mouseY > 400) {
      if (mouseX < 230 && mouseX > 80) {
        OPTION = 1;
      }
      if (mouseX < 550 && mouseX > 400) {
        OPTION = 2;
      }
    }
  } else if (OPTION === 1) {
    //rect(30, 400, 290, 50);
    if (mouseY < 450 && mouseY > 400) {
      if (mouseX < 320 && mouseX > 30) {
        OPTION = 0;
      }
    }
  } else if (OPTION === 2) {
    //go back to main menu
    if (mouseY < 450 && mouseY > 400) {
      if (mouseX < 320 && mouseX > 30) {
        OPTION = 0;
      }
    }
    //easy option
    if (mouseY < 240 && mouseY > 150) {
      if (mouseX < 180 && mouseX > 30) {
        OPTION = 3;
        game.initialize();
      }
    }
    //medium option
    if (mouseY < 240 && mouseY > 150) {
      if (mouseX < 370 && mouseX > 220) {
        OPTION = 4;
        game.initialize();
      }
    }

    //hard option
    if (mouseY < 240 && mouseY > 150) {
      if (mouseX < 560 && mouseX > 410) {
        OPTION = 5;
        game.initialize();
      }
    }
  }
  // in easy option
  else if (OPTION === 3) {
    //rect(20,440,60,20);
    if (mouseY < 460 && mouseY > 440) {
      if (mouseX < 80 && mouseX > 20) {
        OPTION = 0; // back to menu
      }
    }
  }
  // in medium option
  else if (OPTION === 4) {
    //rect(20,440,60,20);
    if (mouseY < 460 && mouseY > 440) {
      if (mouseX < 80 && mouseX > 20) {
        OPTION = 0; // back to menu
      }
    }
  }
  // in hard option
  else if (OPTION === 5) {
    //rect(20,440,60,20);
    if (mouseY < 460 && mouseY > 440) {
      if (mouseX < 80 && mouseX > 20) {
        OPTION = 0; // back to menu
      }
    }
  }
}
